package com.matheus.sensorescomuns;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

//Declaração da classe implements com a abstração do SensorEventListener
public class SensorProximidade extends AppCompatActivity implements SensorEventListener {

    //Declaração
    private Button btnVoltar,btnLuminosidade;
    private TextView resposta;
    private Sensor proximidade;
    private SensorManager medir;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sensor_proximidade);

        //Mapeamento de todos os objetos do nosso layout
        medir = (SensorManager) this.getSystemService(SENSOR_SERVICE);
        proximidade = medir.getDefaultSensor(Sensor.TYPE_PROXIMITY);
        resposta = findViewById(R.id.resposta2);
        btnVoltar = findViewById(R.id.btnVoltar);
        btnLuminosidade = findViewById(R.id.btnLuminosidade);

        //Eventos de botões
        btnVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                botaovoltar();
            }
        });

        btnLuminosidade.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                seguirEmFrente();
            }
        });
    }

    //chamada de callbacks, que tem a função de definir o comportamento do ciclo de vida das activities
    //onResume e onPause
    @Override
    protected void onResume() {
        medir.registerListener(this, proximidade, SensorManager. SENSOR_DELAY_NORMAL);
        super.onResume();
    }

    @Override
    public void onPause() {
        medir.unregisterListener(this,proximidade);
        super.onPause();
    }

    //Método onSe ocorre qdo é exectudo ou modifica algum tipo de evento
    //relacionado ao sensor especificado
    //se o valor do evento for = a zero, é pq estamos proximo ao sensor, se não, estamos afastado.
    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.values[0] == 0){
            getWindow().getDecorView().setBackgroundColor(Color.MAGENTA);
            resposta.setText("Próximo");
        }else{
            getWindow().getDecorView().setBackgroundColor(Color.CYAN);
            resposta.setText("Afastado");
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }

    //Métodos abrimento de activies

    public void botaovoltar(){
        Intent janela1 = new Intent(this, MainActivity.class);
        startActivity(janela1);
    }

    public void seguirEmFrente(){
        Intent janela2 = new Intent(this, SensorLuminosidade.class);
        startActivity(janela2);
    }

}