package com.matheus.mycerveja;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class SensorTemperatura extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sensor_temperatura);
    }
}